package com.eduhunter.stardustoverlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 1001;
    private SharedPreferences prefs;
    private TextView status;
    private TextView alphaLabel;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("overlay", MODE_PRIVATE);
        buildUi();
        requestNotificationIfNeeded();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(30), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(238,239,240));

        TextView title = text("EduHunter Stardust Overlay", 24, true);
        title.setTextColor(Color.rgb(37,40,43));
        root.addView(title);

        TextView sub = text("Overlay clean, monocromático e independente do Pokémon GO.", 14, false);
        sub.setTextColor(Color.rgb(92,96,100));
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1,-2); subP.setMargins(0,dp(8),0,dp(20));
        root.addView(sub, subP);

        status = text("", 14, true);
        status.setPadding(dp(14),dp(12),dp(14),dp(12));
        status.setBackground(OverlayService.roundRect(Color.rgb(218,220,222), 14));
        root.addView(status, new LinearLayout.LayoutParams(-1,-2));

        Button permission = button("Permitir sobre outros apps");
        permission.setOnClickListener(v -> requestOverlayPermission());
        add(root, permission, 14);

        Button start = button("Iniciar / atualizar overlay");
        start.setOnClickListener(v -> startOverlay(OverlayService.ACTION_SHOW_BUBBLE));
        add(root, start, 8);

        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button show = button("Mostrar ícone"); show.setOnClickListener(v -> startOverlay(OverlayService.ACTION_SHOW_BUBBLE));
        Button hide = button("Ocultar ícone"); hide.setOnClickListener(v -> startOverlay(OverlayService.ACTION_HIDE_BUBBLE));
        row.addView(show, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0,dp(48),1); hp.setMargins(dp(8),0,0,0); row.addView(hide,hp);
        add(root,row,8);

        alphaLabel = text("Transparência",14,true);
        add(root,alphaLabel,18);
        SeekBar alpha = new SeekBar(this); alpha.setMax(80); alpha.setProgress(prefs.getInt("alpha", 82)-20);
        alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean from){int value=p+20; prefs.edit().putInt("alpha",value).apply(); alphaLabel.setText("Transparência do overlay: "+value+"%"); startOverlay(OverlayService.ACTION_APPLY_ALPHA);}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        alphaLabel.setText("Transparência do overlay: "+prefs.getInt("alpha",82)+"%");
        root.addView(alpha,new LinearLayout.LayoutParams(-1,-2));

        Button planner = button("Abrir Planner completo");
        planner.setOnClickListener(v -> startActivity(new Intent(this, PlannerActivity.class)));
        add(root, planner, 18);

        Button stop = button("Parar overlay");
        stop.setOnClickListener(v -> { Intent i=new Intent(this,OverlayService.class); i.setAction(OverlayService.ACTION_STOP); startService(i); });
        add(root, stop, 8);

        TextView note = text("Quando o ícone estiver oculto, você pode recuperá-lo por esta tela ou pela ação “Mostrar ícone” na notificação do Android. O painel completo mantém Calculadora, Planejador, Sessão ao vivo, Rotas, Histórico, Gastos, Favoritos e Dados.",12,false);
        note.setTextColor(Color.rgb(95,99,103));
        add(root,note,20);

        setContentView(root);
    }

    private void requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) { refreshStatus(); return; }
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
        startActivityForResult(i, REQ_OVERLAY);
    }

    private void requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != getPackageManager().PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44);
        }
    }

    private void startOverlay(String action) {
        if (!Settings.canDrawOverlays(this)) { requestOverlayPermission(); return; }
        Intent i = new Intent(this, OverlayService.class); i.setAction(action);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        refreshStatus();
    }

    private void refreshStatus() {
        boolean ok = Settings.canDrawOverlays(this);
        status.setText(ok ? "Permissão de sobreposição: LIBERADA" : "Permissão de sobreposição: necessária");
    }

    private TextView text(String s,int sp,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);if(bold)t.setTypeface(null,1);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);b.setBackground(OverlayService.roundRect(Color.rgb(70,74,78),14));return b;}
    private void add(LinearLayout r,View v,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,v instanceof Button?dp(48):-2);p.setMargins(0,dp(top),0,0);r.addView(v,p);}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
