package com.eduhunter.stardustoverlay;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class OverlayService extends Service {
    public static final String ACTION_SHOW_BUBBLE="show_bubble", ACTION_HIDE_BUBBLE="hide_bubble", ACTION_OPEN_PANEL="open_panel", ACTION_APPLY_ALPHA="apply_alpha", ACTION_STOP="stop_overlay";
    private static final int NOTIF_ID=7311; private static final String CH="stardust_overlay";
    private WindowManager wm; private TextView bubble; private LinearLayout panel; private WindowManager.LayoutParams bubbleParams,panelParams;
    private SharedPreferences prefs; private Handler handler=new Handler(Looper.getMainLooper());
    private TextView timerText,capturesText,weatherText,weatherTypesText; private Button sessionButton; private long startedAt=0,elapsed=0; private boolean running=false; private int captures=0;
    private static final String[] WEATHER_NAMES={"Sem bônus","Ensolarado / Limpo","Chuvoso","Parcialmente nublado","Nublado","Ventando","Neve","Névoa"};
    private static final String[] WEATHER_TYPES={"—","Grama • Fogo • Terra","Água • Elétrico • Inseto","Normal • Pedra","Fada • Lutador • Venenoso","Voador • Dragão • Psíquico","Gelo • Aço","Noturno • Fantasma"};
    private final Runnable ticker=new Runnable(){public void run(){updateTimer();handler.postDelayed(this,500);}};

    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("overlay",MODE_PRIVATE);wm=(WindowManager)getSystemService(WINDOW_SERVICE);createChannel();startForeground(NOTIF_ID,notification());if(Settings.canDrawOverlays(this))createViews();handler.post(ticker);}

    @Override public int onStartCommand(Intent i,int flags,int id){String a=i==null?null:i.getAction();if(ACTION_STOP.equals(a)){stopSelf();return START_NOT_STICKY;}if(!Settings.canDrawOverlays(this))return START_STICKY;if(bubble==null)createViews();if(ACTION_SHOW_BUBBLE.equals(a))showBubble();else if(ACTION_HIDE_BUBBLE.equals(a))hideBubble();else if(ACTION_OPEN_PANEL.equals(a))openPanel();else if(ACTION_APPLY_ALPHA.equals(a))applyAlpha();return START_STICKY;}

    private void createViews(){createBubble();createPanel();applyAlpha();}

    private void createBubble(){
        bubble=new TextView(this);bubble.setText("✦");bubble.setTextSize(25);bubble.setTextColor(Color.WHITE);bubble.setGravity(Gravity.CENTER);bubble.setBackground(roundRect(0xD9383B3E,999));bubble.setElevation(dp(8));
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        bubbleParams=new WindowManager.LayoutParams(dp(54),dp(54),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);bubbleParams.gravity=Gravity.TOP|Gravity.START;bubbleParams.x=prefs.getInt("bx",dp(16));bubbleParams.y=prefs.getInt("by",dp(180));
        wm.addView(bubble,bubbleParams);
        bubble.setOnTouchListener(new View.OnTouchListener(){float dx,dy;int sx,sy;long down;public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getAction()){case 0:sx=bubbleParams.x;sy=bubbleParams.y;dx=e.getRawX();dy=e.getRawY();down=System.currentTimeMillis();return true;case 2:bubbleParams.x=sx+(int)(e.getRawX()-dx);bubbleParams.y=sy+(int)(e.getRawY()-dy);wm.updateViewLayout(bubble,bubbleParams);return true;case 1:prefs.edit().putInt("bx",bubbleParams.x).putInt("by",bubbleParams.y).apply();if(System.currentTimeMillis()-down<220)togglePanel();return true;}return false;}});
    }

    private void createPanel(){
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(14),dp(12),dp(14),dp(12));panel.setBackground(roundRect(0xEA34373A,18));panel.setElevation(dp(10));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView title=label("EduHunter  •  Stardust",16,true);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button min=mini("—");min.setOnClickListener(v->closePanel());Button eye=mini("○");eye.setOnClickListener(v->{hideBubble();closePanel();Toast.makeText(this,"Ícone oculto. Use a notificação ou abra o app para mostrar novamente.",Toast.LENGTH_LONG).show();});Button x=mini("×");x.setOnClickListener(v->closePanel());head.addView(min);head.addView(eye);head.addView(x);panel.addView(head,new LinearLayout.LayoutParams(-1,dp(42)));
        View line=new View(this);line.setBackgroundColor(0x55FFFFFF);panel.addView(line,new LinearLayout.LayoutParams(-1,1));

        LinearLayout session=new LinearLayout(this);session.setGravity(Gravity.CENTER_VERTICAL);timerText=label("00:00:00",25,true);session.addView(timerText,new LinearLayout.LayoutParams(0,dp(58),1));sessionButton=smallButton("Iniciar");sessionButton.setOnClickListener(v->toggleSession());session.addView(sessionButton);panel.addView(session,new LinearLayout.LayoutParams(-1,dp(64)));

        LinearLayout capRow=row();TextView cLabel=label("Capturas",14,false);capturesText=label("0",18,true);capRow.addView(cLabel,new LinearLayout.LayoutParams(0,-2,1));capRow.addView(capturesText);panel.addView(capRow);
        LinearLayout btns=new LinearLayout(this);Button p1=smallButton("+1");p1.setOnClickListener(v->addCaptures(1));Button p5=smallButton("+5");p5.setOnClickListener(v->addCaptures(5));Button reset=smallButton("Zerar");reset.setOnClickListener(v->resetSession());btns.addView(p1,new LinearLayout.LayoutParams(0,dp(44),1));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(44),1);bp.setMargins(dp(8),0,0,0);btns.addView(p5,bp);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(44),1);rp.setMargins(dp(8),0,0,0);btns.addView(reset,rp);panel.addView(btns);

        LinearLayout weatherRow=new LinearLayout(this);weatherRow.setOrientation(LinearLayout.VERTICAL);weatherRow.setPadding(0,dp(10),0,dp(4));
        weatherText=label("",13,true);weatherTypesText=label("",11,false);weatherTypesText.setTextColor(0xFFCDD0D2);
        weatherRow.addView(weatherText);weatherRow.addView(weatherTypesText);
        weatherRow.setOnClickListener(v->cycleWeather());
        panel.addView(weatherRow,new LinearLayout.LayoutParams(-1,dp(58)));
        updateWeatherText();

        Button planner=smallButton("Abrir Planner completo");planner.setOnClickListener(v->{Intent a=new Intent(this,PlannerActivity.class);a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(a);});LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(46));pp.setMargins(0,dp(10),0,0);panel.addView(planner,pp);

        TextView alphaTitle=label("Transparência",12,false);LinearLayout.LayoutParams at=new LinearLayout.LayoutParams(-1,-2);at.setMargins(0,dp(12),0,0);panel.addView(alphaTitle,at);SeekBar alpha=new SeekBar(this);alpha.setMax(80);alpha.setProgress(prefs.getInt("alpha",82)-20);alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){prefs.edit().putInt("alpha",p+20).apply();applyAlpha();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});panel.addView(alpha,new LinearLayout.LayoutParams(-1,dp(40)));

        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        panelParams=new WindowManager.LayoutParams(dp(330),WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);panelParams.gravity=Gravity.TOP|Gravity.END;panelParams.x=dp(12);panelParams.y=dp(110);wm.addView(panel,panelParams);panel.setVisibility(View.GONE);
    }

    private void toggleSession(){if(running){elapsed+=System.currentTimeMillis()-startedAt;running=false;sessionButton.setText("Continuar");}else{startedAt=System.currentTimeMillis();running=true;sessionButton.setText("Pausar");}updateTimer();}
    private void resetSession(){running=false;elapsed=0;startedAt=0;captures=0;sessionButton.setText("Iniciar");updateTimer();capturesText.setText("0");}
    private void addCaptures(int n){captures+=n;capturesText.setText(String.valueOf(captures));}
    private void cycleWeather(){int i=(prefs.getInt("weatherIndex",0)+1)%WEATHER_NAMES.length;prefs.edit().putInt("weatherIndex",i).apply();updateWeatherText();}
    private void updateWeatherText(){if(weatherText==null)return;int i=Math.max(0,Math.min(WEATHER_NAMES.length-1,prefs.getInt("weatherIndex",0)));weatherText.setText("Clima: "+WEATHER_NAMES[i]+"   ›");weatherTypesText.setText("Tipos favorecidos: "+WEATHER_TYPES[i]);}
    private void updateTimer(){if(timerText==null)return;long ms=elapsed+(running?System.currentTimeMillis()-startedAt:0);long s=ms/1000,h=s/3600,m=(s%3600)/60,ss=s%60;timerText.setText(String.format(Locale.US,"%02d:%02d:%02d",h,m,ss));}

    private void togglePanel(){if(panel.getVisibility()==View.VISIBLE)closePanel();else openPanel();}
    private void openPanel(){if(panel!=null){panel.setVisibility(View.VISIBLE);applyAlpha();}}
    private void closePanel(){if(panel!=null)panel.setVisibility(View.GONE);}
    private void showBubble(){if(bubble!=null)bubble.setVisibility(View.VISIBLE);}
    private void hideBubble(){if(bubble!=null)bubble.setVisibility(View.GONE);}
    private void applyAlpha(){float a=Math.max(.2f,Math.min(1f,prefs.getInt("alpha",82)/100f));if(panel!=null)panel.setAlpha(a);if(bubble!=null)bubble.setAlpha(Math.max(.45f,a));}

    private Notification notification(){
        PendingIntent show=PendingIntent.getService(this,10,new Intent(this,OverlayService.class).setAction(ACTION_SHOW_BUBBLE),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open=PendingIntent.getService(this,11,new Intent(this,OverlayService.class).setAction(ACTION_OPEN_PANEL),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,12,new Intent(this,OverlayService.class).setAction(ACTION_STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);return b.setSmallIcon(com.eduhunter.stardustoverlay.R.drawable.ic_stat_stardust).setContentTitle("EduHunter Stardust Overlay").setContentText("Overlay ativo • toque nas ações para controlar").setOngoing(true).addAction(new Notification.Action.Builder(null,"Mostrar ícone",show).build()).addAction(new Notification.Action.Builder(null,"Abrir painel",open).build()).addAction(new Notification.Action.Builder(null,"Parar",stop).build()).build();
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel c=new NotificationChannel(CH,"Stardust Overlay",NotificationManager.IMPORTANCE_LOW);c.setDescription("Controles do overlay flutuante");nm.createNotificationChannel(c);}}

    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(0,dp(7),0,dp(7));return r;}
    private TextView label(String s,int sp,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.WHITE);if(bold)t.setTypeface(null,1);return t;}
    private Button mini(String s){Button b=smallButton(s);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(42),dp(38));p.setMargins(dp(4),0,0,0);b.setLayoutParams(p);return b;}
    private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);b.setBackground(roundRect(0x553F4347,12));return b;}
    public static GradientDrawable roundRect(int color,int radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radiusDp);g.setStroke(1,0x557F858A);return g;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}

    @Override public void onDestroy(){handler.removeCallbacks(ticker);if(wm!=null){try{if(bubble!=null)wm.removeView(bubble);}catch(Exception ignored){}try{if(panel!=null)wm.removeView(panel);}catch(Exception ignored){}}super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
