# EduHunter Stardust Overlay — Android V1

APK companheiro independente, sem modificar o Pokémon GO.

## Incluído

- Overlay flutuante arrastável, monocromático e discreto.
- Painel compacto com cronômetro e contador rápido de capturas.
- Atalho de clima no painel compacto, com os tipos favorecidos segundo as regras do jogo.
- Transparência ajustável de 20% a 100%.
- Ocultar completamente o ícone.
- Restaurar o ícone pelo app ou pela notificação persistente.
- Minimizar/abrir o painel.
- Planner completo embarcado em WebView com as funções da versão V3:
  calculadora, clima, eventos, Pedaço de Estrela, comparador, metas, sessão ao vivo,
  rotas, histórico, gastos, favoritos, dados personalizados, JSON/CSV e tema.
- Importação JSON via seletor de arquivos Android.
- Exportação JSON/CSV via seletor de destino Android.

## Observação

Esta V1 não automatiza toques no Pokémon GO e não lê memória do jogo. A leitura automática da tela por MediaProjection/OCR fica separada para uma versão posterior, caso seja desejada.
