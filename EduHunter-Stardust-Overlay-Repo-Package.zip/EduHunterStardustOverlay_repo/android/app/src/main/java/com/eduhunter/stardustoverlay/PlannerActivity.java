package com.eduhunter.stardustoverlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class PlannerActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingText, pendingMime, pendingName;
    private static final int PICK_FILE=2001, SAVE_FILE=2002;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        web.setBackgroundColor(0xFF202224);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.addJavascriptInterface(new Bridge(),"Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,PICK_FILE);return true;
            }
        });
        web.loadUrl("file:///android_asset/planner.html");
        setContentView(web);
    }

    public class Bridge {
        @JavascriptInterface public void saveTextFile(String name,String text,String mime){
            runOnUiThread(()->{pendingName=name;pendingText=text;pendingMime=mime;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime==null?"text/plain":mime);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,SAVE_FILE);});
        }
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==PICK_FILE){if(fileCallback!=null){Uri u=(res==RESULT_OK&&data!=null)?data.getData():null;fileCallback.onReceiveValue(u==null?null:new Uri[]{u});fileCallback=null;}return;}
        if(req==SAVE_FILE&&res==RESULT_OK&&data!=null&&data.getData()!=null){try(OutputStream os=getContentResolver().openOutputStream(data.getData())){os.write((pendingText==null?"":pendingText).getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}}
    }

    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
